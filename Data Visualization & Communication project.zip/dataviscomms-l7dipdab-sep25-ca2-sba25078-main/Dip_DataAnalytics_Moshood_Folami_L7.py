#!/usr/bin/env python
# coding: utf-8

# # Important Libraries

# In[1]:


import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px


# In[2]:


# Loading csv dataset
df = pd.read_csv("Fremont_Bridge_Bicycle_Counter.csv")


# In[3]:


df.head()


# In[4]:


df.info()


# In[5]:


df.shape


# In[6]:


df.isnull().sum()


# In[7]:


df = df.dropna()


# In[8]:


df.isnull().sum()


# In[9]:


df.shape


# In[10]:


df.describe()


# In[11]:


df.head()


# In[12]:


# DATA LOADING
@st.cache_data

def load_data():
    df = pd.read_csv("Fremont_Bridge_Bicycle_Counter.csv")
    
    # renaming every column in the dataframe by trimming whitespace, replacing spaces with underscores, and converting the names to lowercase.
    df.columns = [c.strip().replace(" ", "_").lower() for c in df.columns]
    
    # Renaming columns to total_bikes, west and east
    df = df.rename(columns={
        'date': 'date',
        'fremont_bridge_sidewalks,_south_of_n_34th_st_total': 'total_bikes',
        'fremont_bridge_sidewalks,_south_of_n_34th_st_cyclist_west_sidewalk': 'west',
        'fremont_bridge_sidewalks,_south_of_n_34th_st_cyclist_east_sidewalk': 'east'
    })

    # Converts the date column to a proper datetime type and then extracts year, month, day name, and hour into new columns.
    df['date'] = pd.to_datetime(df['date'])
    df['year'] = df['date'].dt.year
    df['month'] = df['date'].dt.month
    df['dayofweek'] = df['date'].dt.day_name()
    df['hour'] = df['date'].dt.hour
    return df

df = load_data()

# PAGE CONFIG
st.set_page_config(page_title="Fremont Bridge Bike Flows Dashboard", layout="wide")

# SIDEBAR FILTERS
st.sidebar.title("Filters")

# Years
years = sorted(df['year'].unique())
selected_years = st.sidebar.multiselect("Year", years, default=years)

# Days
days = list(df['dayofweek'].unique())
selected_days = st.sidebar.multiselect("Day of Week", days, default=days)

# Time range
time_range = st.sidebar.slider("Hour of Day", 0, 23, (0, 23))

filtered = df[
    df['year'].isin(selected_years)
    & df['dayofweek'].isin(selected_days)
    & df['hour'].between(time_range[0], time_range[1])
]

# Pathway
path_option = st.sidebar.radio("Pathway", ("Total", "West Sidewalk", "East Sidewalk"))

value_col = (
    "total_bikes" if path_option == "Total"
    else "west" if path_option == "West Sidewalk"
    else "east"
)

# HEADER
st.title("Fremont Bridge Bicycle Flows Dashboard")

# KPI ROW
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric("Total rides", f"{int(filtered[value_col].sum()):,}")

with col2:
    st.metric("Avg per hour", f"{filtered[value_col].mean():,.1f}")

with col3:
    busiest = filtered.groupby('hour')[value_col].sum().idxmax()
    st.metric("Busiest hour", f"{busiest:,}")

with col4:
    peak_day = filtered.groupby("dayofweek")[value_col].sum().idxmax()
    st.metric("Peak Day", peak_day)

# TABS FOR ONE-PAGE LAYOUT
tab1, tab2, tab3, tab4 = st.tabs(["Hourly", "Day of Week", "Monthly", "East vs West"])

# TAB 1 – HOURLY
with tab1:
    hourly = filtered.groupby('hour')[value_col].mean().reset_index()

# Average Bikes by Hour
    fig_hour = px.line(
        hourly, x="hour", y=value_col, markers=True,
        title="Average Bikes by Hour",
        labels={"hour": "Hour", value_col: "Average Bikes"}
    )
    fig_hour.update_traces(hovertemplate="Hour: %{x}<br>Bikes: %{y:,.0f}")
    fig_hour.update_layout(yaxis_tickformat=",")
    st.plotly_chart(fig_hour, use_container_width=True)

# TAB 2 – DAY OF WEEK
with tab2:
    dow = (
        filtered.groupby('dayofweek')[value_col]
        .mean()
        .reindex(["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"])
        .reset_index()
    )

# Average Bikes by Day
    fig_dow = px.bar(
        dow, x="dayofweek", y=value_col, text=value_col,
        title="Average Bikes by Day",
        labels={"dayofweek": "Day", value_col: "Average Bikes"}
    )
    fig_dow.update_traces(texttemplate="%{text:,.0f}")
    fig_dow.update_layout(yaxis_tickformat=",")
    st.plotly_chart(fig_dow, use_container_width=True)

# TAB 3 – MONTHLY
with tab3:
    monthly = (
        filtered.set_index('date')
        .resample('M')[value_col]
        .sum()
        .reset_index()
    )

# Monthly Bicycle Traffic
    fig_month = px.area(
        monthly, x="date", y=value_col,
        title="Monthly Bicycle Traffic",
        labels={"date": "Date", value_col: "Total Bikes"}
    )
    fig_month.update_traces(hovertemplate="Date: %{x}<br>Bikes: %{y:,.0f}")
    fig_month.update_layout(yaxis_tickformat=",")
    st.plotly_chart(fig_month, use_container_width=True)

# TAB 4 – EAST VS WEST
with tab4:
    sidewalk_df = (
        filtered[['west', 'east']]
        .sum()
        .reset_index()
        .rename(columns={'index': 'sidewalk', 0: 'count'})
    )
    sidewalk_df['sidewalk'] = sidewalk_df['sidewalk'].str.capitalize()


# East vs West Total Bikes
    fig_sidewalk = px.bar(
        sidewalk_df, x="sidewalk", y="count", text="count",
        title="East vs West Total Bikes",
        labels={"sidewalk": "Sidewalk", "count": "Total Bikes"}
    )
    fig_sidewalk.update_traces(texttemplate="%{text:,.0f}")
    fig_sidewalk.update_layout(yaxis_tickformat=",")
    st.plotly_chart(fig_sidewalk, use_container_width=True)

# RAW DATA
with st.expander("Peek at the data"):
    st.dataframe(filtered[['date', 'west', 'east', 'total_bikes']].head(200))



# In[ ]:




